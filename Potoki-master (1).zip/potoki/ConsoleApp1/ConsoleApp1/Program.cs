﻿List<int> list = new List<int>();   
var first = new Thread(Input);
var second = new Thread(Input);
var third = new Thread(Input);

void Input(object thread)
{
    for (int i = 0; i < 1000; i++)
    {
        Console.WriteLine(i);
    }
 
    list.Add((int)thread);
}


first.Start(1);
second.Start(2);
third.Start(3);
first.Join();
second.Join();
third.Join();
Console.WriteLine($"win {list[0]}");





