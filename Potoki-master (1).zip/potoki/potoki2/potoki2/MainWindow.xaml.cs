﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace potoki2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<int> list = new List<int>();
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void btn(object sender, RoutedEventArgs e)
        {
            var first = new Thread(FibFor);
            first.Start(int.Parse(Input.Text));

            
           //output.Text = list.Last().ToString();
        }
        void FibFor(object count)
        {

            int a = 1;
            int b = 1;
            int temp;
            for (int i = 0; i < (int)count; i++)
            {
                temp = a + b;
                temp = a + b;

            }
            output.Dispatcher.Invoke(new Action(() => { output.Text = mass[mass.Length-1].ToString(); }));
        }
        void Fibonachi(object count)
        {
            // мемоизация
            if ((BigInteger)count == 0 || (BigInteger)count == 1) output.Text = count.ToString();
            BigInteger n = Fibo((BigInteger)count - 1) + Fibo((BigInteger)count - 2);
            output.Dispatcher.Invoke(new Action(() => { output.Text = n.ToString(); }));
         //   output.Text = n.ToString();
        }

        BigInteger Fibo(BigInteger n)
        {
            
            if (n == 0 || n == 1) return n;

            return Fibo(n - 1) + Fibo(n - 2);
        }
    }


}
